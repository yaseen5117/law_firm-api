<?php
	// Paste your config here or run the installer my opening http://<your site>/<installation path>/moxiemanager/
	// Read more at: http://www.moxiemanager.com/documentation/

	// IMPORTANT
	// Make sure the config/plugins does NOT contain any NEW LINES or SPACE outside of the PHP tags since these will be output in streams and break things.
?>
