<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes" />
<script src="js/moxman.loader.min.js"></script>
</head>
<body onload="moxman.browse({fullscreen: true, filelist_insert_toolbar: '', close: false});">
</body>
</html>